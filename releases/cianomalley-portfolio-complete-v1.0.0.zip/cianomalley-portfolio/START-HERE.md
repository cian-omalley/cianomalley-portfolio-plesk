# Cian O'Malley — Digital District (complete package)

A dynamic, animated cyberpunk-brutalist **WordPress theme** — no page builder — ready
to run on **Plesk** (or any WordPress host). This package has everything you need.

## What's in this folder

| File | What it's for |
| --- | --- |
| **`preview-demo.html`** | **Double-click to preview the whole site in your browser** — no install, no internet needed. Click through every page, open case studies, try the menu and animations. |
| **`digital-district.zip`** | The **theme** — upload this to WordPress to run the real site. |
| **`INSTALL-ON-PLESK.md`** | Full install + setup guide (WP Toolkit, mail, SEO, HTTPS). |
| **`LICENSE`** | MIT license. |

## Quick start (3 steps)

1. **Preview it now:** open `preview-demo.html` in any browser to click around the site.
2. **Install WordPress** on your domain (Plesk → WP Toolkit → Install), and set the site
   **Title** and **Tagline** under Settings → General — the theme uses them in the hero
   and footer.
3. **Upload the theme:** wp-admin → **Appearance → Themes → Add New → Upload Theme** →
   choose `digital-district.zip` → **Install** → **Activate**.

That's it. On activation the theme **builds the whole site for you**:

- Pages: Home, About, Contact, Blog
- A nav menu: Home · Work · Projects · Guides · Reviews · Blog · About · Contact
- Sample content: client case studies, guides, reviews, and journal posts
- **Imports your GitHub repositories** into Projects (needs the server to reach
  `api.github.com`)
- Flushes permalinks automatically, so `/work/`, `/projects/`, `/guides/`, `/reviews/`,
  and `/blog/` work immediately

## After install

- **Mail:** enable the domain's mail service in Plesk so the contact form delivers.
- **SEO:** install any free plugin (The SEO Framework, Yoast, Rank Math) — the theme lets
  it control all titles/meta.
- **HTTPS:** issue a free Let's Encrypt certificate in Plesk and force HTTPS.
- **Your content:** edit everything in wp-admin. Re-import repos any time from
  **Projects → Sync GitHub**. Add real client work under **Client Work**.

## Editing / rebuilding

Full source and a rebuild script (`package.sh`) live in the repository:
`github.com/cian-omalley/cianomalley-portfolio-plesk`

Everything is self-hosted and offline-friendly: the three fonts are bundled in the theme,
the hero is a dependency-free canvas, and there are no third-party requests or trackers.
